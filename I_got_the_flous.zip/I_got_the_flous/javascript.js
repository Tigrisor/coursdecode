var dateDebutCommande = 20171101;
var dateFinCommande = 20171130;

// écrire le code de votre programme ici